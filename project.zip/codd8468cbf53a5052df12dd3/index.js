/*
DESCRIPTION:
In this challenge a casino has asked you to make an online dice that works just like 
it would in real life. Using the pre-made dice face that represents ‘one’, make the 
faces for ‘two’, ‘three’, ‘four’, ‘five’ and ‘six’. Now when the users clicks the 
dice on the screen the dice is expected to show one of the faces randomly.

event listeners, Math.random()

*/

// Write your code here 👇


/*

DETAILED INSTRUCTIONS
1. pick out the neccesary elements from the HTML
2. Create other 5 dice faces in CSS
3. use eventlisteners on the appropriate div
4. Display dice faces randomly on click

STRETCH GOALS:
- Can you show the number you rolled as a integer along-side the dice face?
- Can you improve the overall design?
*/

const dice= document.getElementById("dice")
const text =document.getElementById("text")
console.log(text.innerHTML)

dice.addEventListener("click",rolldice)
text.addEventListener("click",rolldice)

function rolldice(){
    let num = Math.floor(Math.random() * 6) + 1;
    console.log(parseInt(text.innerHTML))
    while(num == parseInt(text.innerHTML)){
        num = Math.floor(Math.random() * 6) + 1;
    }
    console.log(num)
    let diceclass = 'odd-'
    if (num % 2 === 0) {
        diceclass= 'even-'
    }
    dice.innerHTML=""
    for( let i=1; i <= num;i++){
        var d=document.createElement("div");
        d.className= `dot ${diceclass}${i}`
        dice.appendChild(d)
        
    }
    text.innerHTML= num
 
}